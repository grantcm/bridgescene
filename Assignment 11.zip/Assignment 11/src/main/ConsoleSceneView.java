package main;


import java.beans.PropertyChangeEvent;

import avatar.BridgeScene;
import scanner.CommandInterpreter;
import util.annotations.Tags;
@Tags({"ConsolveSceneView"})

public class ConsoleSceneView implements java.beans.PropertyChangeListener {
	
	BridgeScene Scene;
	CommandInterpreter Command;

    
	public ConsoleSceneView (BridgeScene AScene, CommandInterpreter aCommand){
		Scene=AScene;
		Command=aCommand;
		Scene.addPropertyChangeListener(this);
		Command.addPropertyChangeListener(this);
		
		
		Scene.getArthur().getLegs().addPropertyChangeListener(this);
		Scene.getArthur().getArms().addPropertyChangeListener(this);
		Scene.getArthur().getBody().addPropertyChangeListener(this);
		Scene.getArthur().getHead().addPropertyChangeListener(this);
		Scene.getArthur().getText().addPropertyChangeListener(this);
		Scene.getArthur().getArms().getLeftLine().addPropertyChangeListener(this);
		Scene.getArthur().getArms().getRightLine().addPropertyChangeListener(this);
		Scene.getArthur().getLegs().getLeftLine().addPropertyChangeListener(this);
		//Galahad
		Scene.getGalahad().getLegs().addPropertyChangeListener(this);
		Scene.getGalahad().getArms().addPropertyChangeListener(this);
		Scene.getGalahad().getBody().addPropertyChangeListener(this);
		Scene.getGalahad().getHead().addPropertyChangeListener(this);
		Scene.getGalahad().getText().addPropertyChangeListener(this);
		Scene.getGalahad().getArms().getLeftLine().addPropertyChangeListener(this);
		Scene.getGalahad().getArms().getRightLine().addPropertyChangeListener(this);
		Scene.getGalahad().getLegs().getLeftLine().addPropertyChangeListener(this);
		//Lancelot
		Scene.getLancelot().getLegs().addPropertyChangeListener(this);
		Scene.getLancelot().getArms().addPropertyChangeListener(this);
		Scene.getLancelot().getBody().addPropertyChangeListener(this);
		Scene.getLancelot().getHead().addPropertyChangeListener(this);
		Scene.getLancelot().getText().addPropertyChangeListener(this);
		Scene.getLancelot().getArms().getLeftLine().addPropertyChangeListener(this);
		Scene.getLancelot().getArms().getRightLine().addPropertyChangeListener(this);
		Scene.getLancelot().getLegs().getLeftLine().addPropertyChangeListener(this);
		//Robin
		Scene.getRobin().getLegs().addPropertyChangeListener(this);
		Scene.getRobin().getArms().addPropertyChangeListener(this);
		Scene.getRobin().getBody().addPropertyChangeListener(this);
		Scene.getRobin().getHead().addPropertyChangeListener(this);
		Scene.getRobin().getText().addPropertyChangeListener(this);
		Scene.getRobin().getArms().getLeftLine().addPropertyChangeListener(this);
		Scene.getRobin().getArms().getRightLine().addPropertyChangeListener(this);
		Scene.getRobin().getLegs().getLeftLine().addPropertyChangeListener(this);
		//Guard
		Scene.getGuard().getLegs().addPropertyChangeListener(this);
		Scene.getGuard().getArms().addPropertyChangeListener(this);
		Scene.getGuard().getBody().addPropertyChangeListener(this);
		Scene.getGuard().getHead().addPropertyChangeListener(this);
		Scene.getGuard().getText().addPropertyChangeListener(this);
		Scene.getGuard().getArms().getLeftLine().addPropertyChangeListener(this);
		Scene.getGuard().getArms().getRightLine().addPropertyChangeListener(this);
		Scene.getGuard().getLegs().getLeftLine().addPropertyChangeListener(this);
		
		Scene.getGuardArea().addPropertyChangeListener(this);
		Scene.getKnightArea().addPropertyChangeListener(this);
	}
	
	@Override
	public void propertyChange(PropertyChangeEvent evt) {
//		String current = "";
//		if(evt.getSource()==Scene.getArthur()){
//			current="Arthur";
//		} else if (evt.getSource()==Scene.getArthur().getHead()){
//			current="Head";
//		} else if (evt.getSource()==Scene.getArthur().getLegs().getLeftLine()){
//			current="Legs";
//		} else if (evt.getSource()==Scene.getArthur().getBody()){
//			current="Body";
//		} else if (evt.getSource()==Scene.getArthur().getArms().getLeftLine()){
//			current="Arms";
//		} else if(evt.getSource()==Scene.getArthur().getText()){
//			current="Text";
//		}
//		System.out.println("Object: "+ current + " \t Property Name: "+ evt.getPropertyName() + "\t OldVal: " + evt.getOldValue() + "\t NewVal: " + evt.getNewValue());
//	
//		System.out.println(evt);
	}
	 

}
