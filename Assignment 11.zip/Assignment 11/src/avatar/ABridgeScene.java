package avatar;

import util.annotations.StructurePattern;
import util.annotations.Tags;

import java.beans.PropertyChangeEvent;
import java.beans.PropertyChangeListener;

import main.APropertyListenerSupport;
import main.PropertyListenerSupport;
import util.annotations.EditablePropertyNames;
import util.annotations.ObserverRegisterer;
import util.annotations.PropertyNames;

@PropertyNames({ "Galahad", "Arthur", "Lancelot", "Robin", "Guard", "Gorge", "KnightArea", "GuardArea" })
@EditablePropertyNames({})
@StructurePattern("Bean Pattern")
@Tags("BridgeScene")

public class ABridgeScene implements BridgeScene {
	private AvatarInterface Arthur, Galahad, Lancelot, Robin, Guard, AreaAvatar;
	private Gorge Gorge;
	private Circle KnightArea, GuardArea;
	private Boolean Occupied = false, KnightTurn = false;
	private int counter = 0;
	PropertyListenerSupport propertysupport = new APropertyListenerSupport();

	public ABridgeScene() {

		Arthur = new Avatar(25, 100, "arthur.jpg", "Hello World", 1);
		Galahad = new Avatar(300, 100, "galahad.jpg", "Hello World", 1);
		Lancelot = new Avatar(75, 300, "lancelot.jpg", "Hello World", 1);
		Robin = new Avatar(300, 250, "robin.jpg", "Fight me!", 1);
		Guard = new Avatar(460, 330, "guard.jpg", "None shall pass!", 2);
		Gorge = new AGorge();
		GuardArea = new ACircle(60, 60, 430, 400);
		KnightArea = new ACircle(40, 40, 320, 400);

	}

	public AvatarInterface getArthur() {
		return Arthur;
	}

	public AvatarInterface getGalahad() {
		return Galahad;
	}

	public AvatarInterface getLancelot() {
		return Lancelot;
	}

	public AvatarInterface getRobin() {
		return Robin;
	}

	public AvatarInterface getGuard() {
		return Guard;
	}

	public Gorge getGorge() {
		return Gorge;
	}

	@Tags("GuardArea")
	public Circle getGuardArea() {
		return GuardArea;
	}

	@Tags("KnightArea")
	public Circle getKnightArea() {
		return KnightArea;
	}

	public boolean preApproach() {
		
		return !Occupied;
	}

	public boolean prePass() {
		return KnightTurn != true && Occupied == true;
	}

	public boolean preFail() {
		return KnightTurn == true && Occupied == true;
	}

	public void Approach(AvatarInterface Avatar) {
		assert (preApproach());
		int x = KnightArea.getX() + 20-Avatar.getX();
		int y = KnightArea.getY() - 25-Avatar.getY();
		Avatar.moveAvatar(x, y);
		Occupied = true;
		propertysupport.notifyAllListeners(new PropertyChangeEvent(this, "this", false, true));
		AreaAvatar = Avatar;
	}

	@Tags("say")
	public void SayScene(String newText) {

		if (counter > 3) {
			counter = 0;
			KnightTurn = false;
			propertysupport.notifyAllListeners(new PropertyChangeEvent(this, "this", true, false));
		} else if (Occupied & KnightTurn) {
			AreaAvatar.setText(newText);
			KnightTurn = false;
			propertysupport.notifyAllListeners(new PropertyChangeEvent(this, "this", true, false));

		} else if (Occupied & KnightTurn == false) {
			Guard.setText(newText);
			KnightTurn = true;
			propertysupport.notifyAllListeners(new PropertyChangeEvent(this, "this", false, true));
			counter += 1;
		}
	}

	@Tags("passed")
	public void PassedScene() {
		assert prePass();
		AreaAvatar.moveAvatar(500, 0);
		Occupied = false;
		propertysupport.notifyAllListeners(new PropertyChangeEvent(this, "this", true, false));
		counter = 0;
	}

	@Tags("failed")
	public void FailedScene() {
		assert preFail();
		Guard.moveAvatar(100, 300);
		KnightTurn = false;
		propertysupport.notifyAllListeners(new PropertyChangeEvent(this, "this", true, false));

	}

	public void ScrollScene(int x, int y) {
		Gorge.moveGorge(x, y);
		Arthur.moveAvatar(x, y);
		Lancelot.moveAvatar(x, y);
		Galahad.moveAvatar(x, y);
		Robin.moveAvatar(x, y);
		Guard.moveAvatar(x, y);
		KnightArea.moveCircle(x, y);
		GuardArea.moveCircle(x, y);
	}

	@Override
	public void addPropertyChangeListener(PropertyChangeListener arg0) {
		propertysupport.add(arg0);
	}
}
