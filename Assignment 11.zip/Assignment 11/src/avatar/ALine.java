package avatar;

import java.beans.PropertyChangeEvent;

import main.APropertyListenerSupport;
import main.PropertyListenerSupport;
import util.annotations.EditablePropertyNames;
import util.annotations.PropertyNames;
import util.annotations.StructurePattern;
import util.annotations.StructurePatternNames;
import util.annotations.Visible;

@StructurePattern(StructurePatternNames.LINE_PATTERN)
@PropertyNames({ "width", "height", "x", "y" })
@EditablePropertyNames({ "width", "height", "x", "y" })
public class ALine extends ALocatable implements Line, util.models.PropertyListenerRegisterer {
	int width, height, length, X2, Y2;
	Point location;
	PropertyListenerSupport propertysupport = new APropertyListenerSupport();

	public ALine(int newX, int newY, int initWidth, int initHeight) {

		super(newX, newY);
		width = initWidth;
		height = initHeight;

	}

	public void rotateLine(double Angle) {
		length = (int) Math.sqrt(Math.pow(width, 2) + Math.pow(height, 2));

		this.setHeight((int) (Math.sin(Angle * Math.PI / 32) * length));

		this.setWidth((int) (Math.cos(Angle * Math.PI / 32) * length));
	}

	public int getWidth() {
		return width;
	}

	public void setWidth(int newVal) {
		int oldVal = width;
		width = newVal;
		propertysupport.notifyAllListeners(new PropertyChangeEvent(this, "Height", oldVal, height));

	}

	public int getHeight() {
		return height;
	}

	public void setHeight(int newVal) {
		int oldVal = height;
		height = newVal;
		propertysupport.notifyAllListeners(new PropertyChangeEvent(this, "Width", oldVal, width));
	}
	@Visible(false)
	public int getX2() {
		X2=X+width;
		return X2;
	}
	@Visible(false)
	public int getY2() {
		Y2=Y+height;
		return Y2;
	}

}
