package scanner;

import util.annotations.EditablePropertyNames;
import util.annotations.PropertyNames;
import util.annotations.StructurePattern;
import util.annotations.StructurePatternNames;
import util.annotations.Tags;

@Tags({ "ScannerBean" })
@StructurePattern(StructurePatternNames.BEAN_PATTERN)
@PropertyNames({ "ScannedString","Tokens" })
@EditablePropertyNames({ "ScannedString" })

public class Bean implements BeanInterface {

	private String ScannedString="";
	private TokenInterface[] Tokens;

	public String getScannedString() {
		// getter
		return ScannedString;
	}

	public void setScannedString(String input) {
		// setter
		ScannedString=input;
		Tokens=scanner.ScanString(ScannedString);

	}
	
	public TokenInterface[] getTokens(){
		return Tokens;	
	}


}
