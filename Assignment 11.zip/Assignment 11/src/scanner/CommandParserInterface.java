package scanner;

import avatar.AvatarInterface;

public interface CommandParserInterface {
	public void setCommandText(String newCommandText);

	public Runnable getCommandObject();

	public Runnable parseCommand(TokenInterface Token);

	public Runnable parseSay(String newtext);

	public Runnable parseMove(AvatarInterface newAvatar, int newx, int newy);

	public Runnable parseApproach(AvatarInterface newAvatar);

	public Runnable parsePass();

	public Runnable parseFail();

	public Runnable parseCommandList();

	public Runnable parseRepeat(int repeats);
}
