package avatar;

import java.beans.PropertyChangeEvent;
import main.PropertyListenerSupport;
import main.APropertyListenerSupport;
import util.annotations.PropertyNames;
import util.annotations.Tags;

@Tags({"Locatable" ,"BoundedShape"})
@PropertyNames({"X","Y","Height","Width"})
public abstract class ABoundedShape extends ALocatable implements util.models.PropertyListenerRegisterer{
	int X,Y,Height,Width;
	
	PropertyListenerSupport propertysupport = new APropertyListenerSupport();
	
	public ABoundedShape(int newX, int newY, int newHeight, int newWidth){
		super(newX,newY);
		Height=newHeight;
		Width=newWidth;
	}
	public int getWidth(){
		return Width;
	}
	public int getHeight(){
		return Height;
	}
	public void setHeight(int newHeight){
		int oldHeight = Height;
		Height=newHeight;
		propertysupport.notifyAllListeners(new PropertyChangeEvent(this, "Height",
				oldHeight, newHeight));
	}
	public void setWidth(int newWidth){
		int oldWidth = Width;
		Width=newWidth;
		propertysupport.notifyAllListeners(new PropertyChangeEvent(this, "Width",
				oldWidth, newWidth));
	}
}
