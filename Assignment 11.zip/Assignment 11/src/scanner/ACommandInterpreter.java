package scanner;

import java.beans.PropertyChangeEvent;
import java.beans.PropertyChangeListener;

import avatar.BridgeScene;
import main.APropertyListenerSupport;
import main.Animator;
import main.AnimatorCommand;
import main.AnimatorInterace;
import main.ClearanceManager;
import main.PropertyListenerSupport;
import util.annotations.EditablePropertyNames;
import util.annotations.ObserverRegisterer;
import util.annotations.PropertyNames;
import util.annotations.StructurePattern;
import util.annotations.StructurePatternNames;
import util.annotations.Tags;

@PropertyNames({ "Command" })
@EditablePropertyNames({ "Command" })
@Tags("CommandInterpreter")
@StructurePattern(StructurePatternNames.BEAN_PATTERN)


public class ACommandInterpreter implements CommandInterpreter {
	int negative = -1;
	String Command = "";
	BridgeScene Scene;
	BeanInterface Bean;
	AnimatorInterace AnimateRobin, AnimateArthur, AnimateLancelot,AnimateGalahad;
	Thread currentThread, thread1, thread2, thread3, thread4;
	ClearanceManager Manager;

	static TokenInterface[] ScannedTokens;
	PropertyListenerSupport propertysupport = new APropertyListenerSupport();

	

	public ACommandInterpreter(BridgeScene newScene, BeanInterface newBean, ClearanceManager newManager) {
		Scene = newScene;
		Manager=newManager;
		AnimateRobin = new Animator(Scene.getRobin());
		AnimateArthur= new Animator(Scene.getArthur());
		AnimateLancelot = new Animator(Scene.getLancelot());
		AnimateGalahad = new Animator(Scene.getGalahad());
	}

	
	public void setCommand(String newString) {
		CommandParserInterface parse = new CommandParser(Scene);
		parse.setCommandText(newString);
		propertysupport.notifyAllListeners(new PropertyChangeEvent(this, "this", "", newString));
		(parse.getCommandObject()).run();
	}


	public String getCommand() {
		return Command;
	}

	@Tags({ "asynchronusRobin" })
	public  void asynchronusRobin() {
		
		Runnable robin = new AnimatorCommand(AnimateRobin);
		Thread moveRobin = new Thread(robin);
		moveRobin.start();
	}

	@Tags({ "asynchronusArthur" })
	public  void asynchronusArthur() {
		Runnable arthur = new AnimatorCommand(AnimateArthur);
		Thread moveArthur = new Thread(arthur);
		moveArthur.start();
	}

	@Tags({ "asynchronusGalahad" })
	public  void asynchronusGalahad() {
		
		Runnable galahad = new AnimatorCommand(AnimateGalahad);
		Thread moveGalahad = new Thread(galahad);
		moveGalahad.start();
	}

	@Tags({ "asynchronusLancelot" })
	public  void asynchronusLancelot() {
		
		Runnable lancelot = new AnimatorCommand(AnimateLancelot);
		Thread moveLancelot = new Thread(lancelot);
		moveLancelot.start();
	}
	
	@Tags({ "waitingRobin" })
	public  void waitingRobin() {
		
		Runnable robin = new AnimatorCommand(AnimateRobin, Manager);
		Thread moveRobin = new Thread(robin);
		moveRobin.start();
	}

	@Tags({ "waitingArthur" })
	public  void waitingArthur() {
		Runnable arthur = new AnimatorCommand(AnimateArthur, Manager);
		Thread moveArthur = new Thread(arthur);
		moveArthur.start();
	}

	@Tags({ "waitingGalahad" })
	public  void waitingGalahad() {
		
		Runnable galahad = new AnimatorCommand(AnimateGalahad, Manager);
		Thread moveGalahad = new Thread(galahad);
		moveGalahad.start();
	}

	@Tags({ "waitingLancelot" })
	public  void waitingLancelot() {
		
		Runnable lancelot = new AnimatorCommand(AnimateLancelot, Manager);
		Thread moveLancelot = new Thread(lancelot);
		moveLancelot.start();
	}
	
	@Tags({"startAnimation"})
	public void startAnimation (){
		Manager.proceedAll();
	}
	
	
	public void addPropertyChangeListener(PropertyChangeListener arg0) {
		propertysupport.add(arg0);
	}
}
