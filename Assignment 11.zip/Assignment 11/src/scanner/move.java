package scanner;
import util.annotations.Tags;

@Tags({"move"})

public class move extends word implements WordInterface{
	
	public move(String newInput){
		super(newInput);
	}
}
