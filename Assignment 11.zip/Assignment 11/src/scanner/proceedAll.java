package scanner;

import util.annotations.Tags;

@Tags({ "proceedAll" })

public class proceedAll extends word implements WordInterface{

	public proceedAll(String newInput) {
		
		super(newInput);
	}
}
