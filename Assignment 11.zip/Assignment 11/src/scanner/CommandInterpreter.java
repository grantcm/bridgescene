package scanner;

import java.beans.PropertyChangeListener;

public interface CommandInterpreter {
	public void setCommand(String newString);

	public String getCommand();
	public void asynchronusLancelot();
	public void asynchronusArthur();
	public void asynchronusGalahad();
	public void asynchronusRobin();
	public void waitingRobin();
	public void waitingLancelot();
	public void waitingArthur();
	public void waitingGalahad();
	public void startAnimation();
	public void addPropertyChangeListener(PropertyChangeListener arg0);
}
