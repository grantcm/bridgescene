package scanner;

import util.annotations.Tags;
import util.misc.ThreadSupport;

@Tags({ "Repeat" })
public class RepeatingCommand implements Runnable {
	int Repeat;
	Runnable Command;

	public RepeatingCommand(int newRepeat, Runnable newCommand) {
		Command = newCommand;
		Repeat = newRepeat;
	}

	public void run() {
		synchronized (this) {
			for (int i = 0; i < Repeat; i++) {
				Command.run();
				ThreadSupport.sleep(1000);
			}
		}
	}
}
