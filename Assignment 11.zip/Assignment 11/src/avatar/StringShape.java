package avatar;

public interface StringShape extends Locatable{
	
	public String getText();
	public void setText(String newText);
}
