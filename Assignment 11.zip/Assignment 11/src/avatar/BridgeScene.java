package avatar;

import java.beans.PropertyChangeListener;

import util.models.PropertyListenerRegisterer;

public interface BridgeScene extends PropertyListenerRegisterer{

	public AvatarInterface getArthur();

	public AvatarInterface getGalahad();

	public AvatarInterface getLancelot();

	public AvatarInterface getRobin();

	public AvatarInterface getGuard();

	public Gorge getGorge();

	public Circle getGuardArea();

	public Circle getKnightArea();

	public void Approach(AvatarInterface Avatar);

	public void SayScene(String newText);

	public void PassedScene();

	public void FailedScene();

	public void ScrollScene(int x, int y);

	public void addPropertyChangeListener(PropertyChangeListener arg0);

}
