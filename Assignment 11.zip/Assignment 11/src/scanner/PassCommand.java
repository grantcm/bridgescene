package scanner;

import avatar.BridgeScene;
import util.misc.ThreadSupport;

public class PassCommand implements Runnable {
	private int animationPauseTime = 30;
	BridgeScene Scene;

	public PassCommand(BridgeScene newScene) {
		Scene = newScene;

	}

	public  void run() {
		synchronized(this){
		
		Scene.PassedScene();
		ThreadSupport.sleep(animationPauseTime);
		}
	}

}
