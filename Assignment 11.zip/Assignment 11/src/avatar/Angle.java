package avatar;

import java.beans.PropertyChangeListener;

public interface Angle {

	public Line getLeftLine();

	public Line getRightLine();

	public void setLength(int x, int y);

	public void setOrigin(int x, int y);

	public void addPropertyChangeListener(PropertyChangeListener arg0);
}
