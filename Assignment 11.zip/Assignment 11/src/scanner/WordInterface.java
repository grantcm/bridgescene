package scanner;

public interface WordInterface extends TokenInterface{

}