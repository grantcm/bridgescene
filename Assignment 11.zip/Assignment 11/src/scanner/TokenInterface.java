package scanner;

public interface TokenInterface {

	String getInput();
	String getValue();
	

	void setInput(String newInput);
}