package scanner;
import util.annotations.Tags;
import util.annotations.StructurePattern;
import util.annotations.StructurePatternNames;
import util.annotations.PropertyNames;
import util.annotations.EditablePropertyNames;

@Tags({ "Minus" })
@StructurePattern(StructurePatternNames.BEAN_PATTERN)
@PropertyNames({ "Input" , "Value"})
@EditablePropertyNames({ "Input" })

public class minus extends word implements TokenInterface{

	String Input;

	public minus(String newInput) {
		super(newInput);
	}
}
