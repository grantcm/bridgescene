package scanner;

import avatar.AvatarInterface;
import avatar.BridgeScene;
import util.misc.ThreadSupport;

public class ApproachCommand implements Runnable {

	BridgeScene Scene;
	AvatarInterface Avatar;
	

	public ApproachCommand(BridgeScene newScene, AvatarInterface newAvatar) {
		Scene = newScene;
		Avatar = newAvatar;

	}

	public void run() {
		synchronized (this) {
			
			Scene.Approach(Avatar);
		}
	}

}
