package scanner;
import util.annotations.Tags;
import util.annotations.StructurePattern;
import util.annotations.StructurePatternNames;
import util.annotations.PropertyNames;
import util.annotations.EditablePropertyNames;

@Tags({ "Plus" })
@StructurePattern(StructurePatternNames.BEAN_PATTERN)
@PropertyNames({ "Input" , "Value"})
@EditablePropertyNames({ "Input" })

public class plus extends word implements TokenInterface{

	public plus(String newInput) {
		super(newInput);
	}
}
