package main;

import java.awt.event.KeyEvent;
import java.awt.event.MouseEvent;

import avatar.BridgeScene;

public class AController extends BridgeScenePainter implements Controller {
	int x, y;
	BridgeScene aScene;
	BridgeScenePainter aView;

	public AController(BridgeScene newScene, BridgeScenePainter newView) {
		super(newScene);
		Scene=newScene;
		aView = newView;
		aView.addMouseListener(this);
		aView.addKeyListener(this);

	}

	public void mouseClicked(MouseEvent e) {
		x=e.getX();
		y=e.getY();
		System.out.println(x+" "+y);
	}

	public void mouseEntered(MouseEvent e) {
	}

	public void mouseExited(MouseEvent e) {
	}

	public void mousePressed(MouseEvent e) {
	}

	public void mouseReleased(MouseEvent e) {
	}

	public void keyTyped(KeyEvent e) {
		 
	}

	public void keyPressed(KeyEvent e) {
		if(e.getKeyCode()==KeyEvent.VK_A){
			Scene.getArthur().moveAvatar(x, y);
		} else if(e.getKeyCode()==KeyEvent.VK_L){
			Scene.getLancelot().moveAvatar(x, y);
		} else if (e.getKeyCode()==KeyEvent.VK_G){
			Scene.getGalahad().moveAvatar(x, y);
		} else if (e.getKeyCode()==KeyEvent.VK_R){
			Scene.getRobin().moveAvatar(x, y);
		} else if (e.getKeyCode()==KeyEvent.VK_O){
			Scene.getArthur().moveOrigin();
			Scene.getLancelot().moveOrigin();
			Scene.getRobin().moveOrigin();
			Scene.getGalahad().moveOrigin();
		}
	}

	public void keyReleased(KeyEvent e) {

	}
}
