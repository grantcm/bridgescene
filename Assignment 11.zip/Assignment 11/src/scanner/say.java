package scanner;


import util.annotations.Tags;

@Tags({"say"})
public class say extends word implements WordInterface{
	
	public say(String newInput){
		super(newInput);
	}
}
