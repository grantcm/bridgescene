package avatar;

import util.annotations.PropertyNames;
import util.annotations.StructurePattern;
import util.annotations.StructurePatternNames;
@PropertyNames({"Height","Width","x","y"})
@StructurePattern(StructurePatternNames.OVAL_PATTERN)

public class ACircle extends ABoundedShape implements Circle{
	int x,y,height, width;
	public ACircle(int H, int W, int X, int Y){
		super(X,Y,W,H);
		
	}
	
	public void moveCircle(int moveX , int moveY){
		x+=moveX;
		y+=moveY;
	}
}
