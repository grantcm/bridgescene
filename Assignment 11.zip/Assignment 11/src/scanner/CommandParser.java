package scanner;

import avatar.AvatarInterface;
import avatar.BridgeScene;
import util.annotations.EditablePropertyNames;
import util.annotations.PropertyNames;
import util.annotations.Tags;

@Tags({ "Parser" })
@PropertyNames({ "CommandText", "CommandObject" })
@EditablePropertyNames({ "CommandText" })
public class CommandParser implements CommandParserInterface {

	Table<String,AvatarInterface> ANewTable = new ATable<String,AvatarInterface>();
	BeanInterface Bean = new Bean();
	AvatarInterface avatar;
	BridgeScene Scene;
	String CommandText, text;
	int x, y, index = 0;
	Runnable Command;
	static TokenInterface[] ScannedTokens;
	CommandListInterface CommandList = new CommandList();

	public CommandParser(BridgeScene newScene) {

		Scene = newScene;
		ANewTable.put("arthur", Scene.getArthur());
		ANewTable.put("galahad", Scene.getGalahad());
		ANewTable.put("robin", Scene.getRobin());
		ANewTable.put("guard", Scene.getGuard());
		ANewTable.put("lancelot", Scene.getLancelot());

	}

	public void setCommandText(String newCommandText) {
		index = 0;
		CommandText = newCommandText;
		Bean.setScannedString(CommandText);
		ScannedTokens = new TokenInterface[(Bean.getTokens()).length];
		ScannedTokens = Bean.getTokens();
		while (index < ScannedTokens.length) {
			if ( ScannedTokens[index] instanceof end){
				break;
			} else{
			CommandList.addCommand(parseCommand(ScannedTokens[index]));
			}
		}
	}

	public Runnable getCommandObject() {
		return CommandList;
	}

	@Tags({ "parseCommand" })
	public Runnable parseCommand(TokenInterface Token) {

		if (ScannedTokens[index] instanceof say) {
			Command = parseSay(((TokenInterface) ScannedTokens[index + 1]).getValue());
			index += 2;

			return Command;
		} else if (ScannedTokens[index] instanceof move) {

			Command = parseMove(
					((AvatarInterface) ANewTable.get(((WordInterface) ScannedTokens[index + 1]).getValue())),
					parseNumber(), parseNumber());
			index += 2;
			return Command;
		} else if (ScannedTokens[index] instanceof Approach) {
			Command = parseApproach(
					((AvatarInterface) ANewTable.get(((WordInterface) ScannedTokens[index + 1]).getValue())));
			index += 2;
			return Command;
		} else if (ScannedTokens[index] instanceof pass) {
			Command = parsePass();
			index += 1;
			return Command;
		} else if (ScannedTokens[index] instanceof fail) {
			Command = parseFail();
			index += 1;
			return Command;
		} else if (ScannedTokens[index] instanceof repeat) {
			Command = parseRepeat(((NumberInterface) ScannedTokens[index + 1]).getNumValue());

			return Command;
		} else if (ScannedTokens[index] instanceof start ){
			index++;
			Command = parseCommandList();
			return Command;
		}

		return null;
	}

	@Tags({ "parseSay" })
	public synchronized Runnable parseSay(String newtext) {
		Runnable Say = new SayCommand(Scene, newtext);
		return Say;
	}

	@Tags({ "numberParser" })
	public int parseNumber() {
		index += 2;
		if (ScannedTokens[index] instanceof plus) {

			return ((NumberInterface) ScannedTokens[index + 1]).getNumValue();
		} else if (ScannedTokens[index] instanceof minus) {

			return ((NumberInterface) ScannedTokens[index + 1]).getNumValue() * -1;
		}
		return 1;
	}

	@Tags({ "parseMove" })
	public Runnable parseMove(AvatarInterface newAvatar, int newx, int newy) {
		avatar = newAvatar;
		x = newx;
		y = newy;
		Runnable Move = new MoveCommand(avatar, x, y);
		return Move;
	}

	@Tags({ "parseApproach" })
	public Runnable parseApproach(AvatarInterface newAvatar) {
		avatar = newAvatar;
		Runnable approach = new ApproachCommand(Scene, avatar);
		return approach;
	}

	@Tags({ "parsePass" })
	public Runnable parsePass() {
		Runnable Pass = new PassCommand(Scene);
		return Pass;
	}

	@Tags({ "parseFail" })
	public Runnable parseFail() {
		Runnable Fail = new FailCommand(Scene);
		return Fail;
	}

	@Tags({ "parseCommandList" })
	public Runnable parseCommandList() {
		Runnable CommandList;
		while (!((ScannedTokens[index]) instanceof end)){
			CommandList = parseCommand(ScannedTokens[index]);
			
			return CommandList;
		}
		return null;
		
	}

	@Tags({ "Repeat" })
	public Runnable parseRepeat(int repeats) {
		Runnable RepeatCommand;
		index += 2;
		RepeatCommand = parseCommand(ScannedTokens[index]);

		Runnable Repeat = new RepeatingCommand(repeats, RepeatCommand);
		return Repeat;
	}

}
