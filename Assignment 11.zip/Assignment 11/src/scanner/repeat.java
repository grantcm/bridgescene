package scanner;

import util.annotations.Tags;

@Tags({ "repeat" })

public class repeat extends word implements WordInterface {

	public repeat(String newInput) {
		super(newInput);
	}
}
