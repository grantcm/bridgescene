package scanner;

import util.annotations.Tags;
import util.annotations.StructurePattern;
import util.annotations.StructurePatternNames;
import util.annotations.PropertyNames;
import util.annotations.EditablePropertyNames;

@Tags({ "Word" })
@StructurePattern(StructurePatternNames.BEAN_PATTERN)
@PropertyNames({ "Input", "Value" })
@EditablePropertyNames({ "Input" })

public class word implements WordInterface{

	String Input;
	private String Value;

	public word(String newInput) {
		Input = newInput;
		Value = Input.toLowerCase();
	}

	public String getInput() {
		return Input;
	}

	public void setInput(String newInput) {
		Input = newInput;
		Value = Input.toLowerCase();
	}

	public String getValue() {
		return Value;
	}

}
