package avatar;
import util.annotations.Explanation;
import util.annotations.StructurePattern;
import util.annotations.StructurePatternNames;
@StructurePattern(StructurePatternNames.POINT_PATTERN)
@Explanation("Uses Cartesian representation.")
public class APoint extends ALocatable implements Point {	
	protected int x, y;
	public APoint(int theX, int theY) {
		super(theX,theY);
	}	
}
