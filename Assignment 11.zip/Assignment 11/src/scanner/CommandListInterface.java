package scanner;

public interface CommandListInterface extends Runnable{
	public void addCommand( Runnable newCommand);

}
