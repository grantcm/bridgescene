package main;

import avatar.AvatarInterface;
import util.annotations.Tags;
import util.misc.ThreadSupport;

public class Animator implements AnimatorInterace {

	int x;
	AvatarInterface avatar;

	public Animator(AvatarInterface newAvatar) {
		avatar = newAvatar;
		
	}

	@Tags({ "animateAvatar" })
	public synchronized void animate() {
		x=0;
		while (x < 50) {
			avatar.moveAvatar(1, 1);
			ThreadSupport.sleep(30);
			x++;
		}
		ThreadSupport.sleep(300);
	}
}
