package scanner;

import util.annotations.Tags;

@Tags("Table")
public interface Table<K,V> {
	public void put(String key, Object val);

	public Object get(String key);

	public Object get(int index);

	public int length();
}
