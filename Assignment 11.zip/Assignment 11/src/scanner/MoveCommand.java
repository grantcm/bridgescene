package scanner;

import avatar.AvatarInterface;
import util.annotations.Tags;
import util.misc.ThreadSupport;

@Tags({ "MoveCommand" })
public class MoveCommand implements Runnable {
	AvatarInterface avatar;
	int animationStep = 5, animationStepX, animationStepY, x, y;
	int animationPauseTime = 30;
	int X, Y;

	public MoveCommand(AvatarInterface newAvatar, int newX, int newY) {

		avatar = newAvatar;

		X = newX;
		Y = newY;
		x = newX;
		y = newY;
	}

	public synchronized void run() {

		if (X < 0) {
			x = Math.abs(X);
		} else if (Y < 0) {
			y = Math.abs(Y);
		}
		int distance = 0;
		animationStepX = X / x;
		animationStepY = Y / y;

		while (distance <= x) {
			avatar.moveAvatar(animationStepX, 0);
			distance += animationStep;
			ThreadSupport.sleep(animationPauseTime);
		}
		distance = 0;
		while (distance <= y) {
			avatar.moveAvatar(0, animationStepY);
			distance += animationStep;
			ThreadSupport.sleep(animationPauseTime);
		}

	}

}
