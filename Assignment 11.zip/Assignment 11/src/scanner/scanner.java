package scanner;

public class scanner {
	static int StringIndex;
	static TokenInterface[] largeTokenArray;
	static TokenInterface[] Tokens;

	public static TokenInterface[] ScanString(String input) {
		StringIndex = 0;
		String temp = "";

		input += " ";

		largeTokenArray = new TokenInterface[input.length()];

		for (int i = 0; i < input.length(); i++) {

			if (Character.isDigit(input.charAt(i))) {
				temp += input.charAt(i);

				if (input.charAt(i + 1) == ' ') {
					// Checks if next position is a space, parses the temp if
					// true
					TokenInterface newToken = new number(temp);

					largeTokenArray[StringIndex] = newToken;
					StringIndex++;
					temp = "";

				}
			} else if (input.charAt(i) == '"') {
				i++;
				while (input.charAt(i) != '"' && i < input.length() - 1) {
					// loops until the end quotation is reached or the end of
					// the input string is reached
					temp += input.charAt(i);

					i++;
				}

				if (input.charAt(i) != '"') {
					// checks for closing quotation mark
					System.out.println("Missing quotation mark");

				}

				TokenInterface newToken = new quote(temp);
				largeTokenArray[StringIndex] = newToken;
				StringIndex++;
				temp = "";

			} else if (isLetter(input.charAt(i))) {

				temp += input.charAt(i);

				if (input.charAt(i + 1) == ' ') {
					// Checks if next position is a space, prints the temp if
					// true
					isWord(temp);
					temp = "";

				}
			} else if (input.charAt(i) == '+') {
				// Prints signs
				TokenInterface newToken = new plus("+");
				largeTokenArray[StringIndex] = newToken;
				StringIndex++;

			} else if (input.charAt(i) == '-') {
				TokenInterface newToken = new minus("-");
				largeTokenArray[StringIndex] = newToken;
				StringIndex++;

			} else if (input.charAt(i) == '{') {
				TokenInterface newToken = new start("{");
				largeTokenArray[StringIndex] = newToken;
				StringIndex++;

			} else if (input.charAt(i) == '}') {

				TokenInterface newToken = new end("}");
				largeTokenArray[StringIndex] = newToken;
				StringIndex++;

			} else if (input.charAt(i) != ' ') {

				// Prints out any characters not involved in the scanner
				System.out.println("Invalid Character: " + input.charAt(i));

			}
		}

		Tokens = new TokenInterface[StringIndex];

		for (int i = 0; i < Tokens.length; i++) {
			Tokens[i] = largeTokenArray[i];

		}
		return Tokens;

	}

	public static void isWord(String input) {

		if (input.equalsIgnoreCase("call")) {
			TokenInterface newToken = new call(input);
			largeTokenArray[StringIndex] = newToken;
			StringIndex++;
		} else if (input.equalsIgnoreCase("define")) {
			TokenInterface newToken = new define(input);
			largeTokenArray[StringIndex] = newToken;
			StringIndex++;
		} else if (input.equalsIgnoreCase("move")) {
			TokenInterface newToken = new move(input);
			largeTokenArray[StringIndex] = newToken;
			StringIndex++;
		}else if (input.equalsIgnoreCase("proceedAll")) {
			TokenInterface newToken = new proceedAll(input);
			largeTokenArray[StringIndex] = newToken;
			StringIndex++;
		} else if (input.equalsIgnoreCase("redo")) {
			TokenInterface newToken = new redo(input);
			largeTokenArray[StringIndex] = newToken;
			StringIndex++;
		} else if (input.equalsIgnoreCase("repeat")) {
			TokenInterface newToken = new repeat(input);
			largeTokenArray[StringIndex] = newToken;
			StringIndex++;
		} else if (input.equalsIgnoreCase("rotateLeftArm")) {
			TokenInterface newToken = new rotateLeftArm(input);
			largeTokenArray[StringIndex] = newToken;
			StringIndex++;
		} else if (input.equalsIgnoreCase("rotateRightArm")) {
			TokenInterface newToken = new rotateRightArm(input);
			largeTokenArray[StringIndex] = newToken;
			StringIndex++;
		} else if (input.equalsIgnoreCase("say")) {
			TokenInterface newToken = new say(input);
			largeTokenArray[StringIndex] = newToken;
			StringIndex++;
		} else if (input.equalsIgnoreCase("sleep")) {
			TokenInterface newToken = new sleep(input);
			largeTokenArray[StringIndex] = newToken;
			StringIndex++;
		} else if (input.equalsIgnoreCase("thread")) {
			TokenInterface newToken = new thread(input);
			largeTokenArray[StringIndex] = newToken;
			StringIndex++;
		} else if (input.equalsIgnoreCase("undo")) {
			TokenInterface newToken = new undo(input);
			largeTokenArray[StringIndex] = newToken;
			StringIndex++;
		} else if (input.equalsIgnoreCase("wait")) {
			TokenInterface newToken = new wait(input);
			largeTokenArray[StringIndex] = newToken;
			StringIndex++;
		} else if (input.equalsIgnoreCase("approach")) {
			TokenInterface newToken = new Approach(input);
			largeTokenArray[StringIndex] = newToken;
			StringIndex++;
		}  else if (input.equalsIgnoreCase("fail")) {
			TokenInterface newToken = new fail(input);
			largeTokenArray[StringIndex] = newToken;
			StringIndex++;
		}  else if (input.equalsIgnoreCase("pass")) {
			TokenInterface newToken = new pass(input);
			largeTokenArray[StringIndex] = newToken;
			StringIndex++;
		} else {
			TokenInterface newToken = new word(input);
			largeTokenArray[StringIndex] = newToken;
			StringIndex++;
		}
	}

	public static boolean isLetter(char input) {
		if (input >= 'A' && input <= 'z') {
			// Determines if the char is a letter
			return true;
		}
		return false;

	}
}
