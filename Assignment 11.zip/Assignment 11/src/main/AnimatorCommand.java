package main;

import util.annotations.Tags;
import util.misc.ThreadSupport;

@Tags({ "Animatorcommand" })
public class AnimatorCommand implements Runnable {

	AnimatorInterace Animation;
	ClearanceManager Manager;

	public AnimatorCommand(AnimatorInterace newAnimation) {
		Animation = newAnimation;
	}

	public AnimatorCommand(AnimatorInterace newAnimation, ClearanceManager newManager) {

		Animation = newAnimation;
		Manager = newManager;

	}

	public void run() {
		try {
			Manager.waitForProceed();
		} catch (NullPointerException e) {
			
		}
		Animation.animate();

	}

}
