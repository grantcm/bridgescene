package main;

public interface AnimatorInterace {
	public void animate();
}
