package scanner;
import util.annotations.Tags;

@Tags({"define"})
public class define extends word implements WordInterface{

	public define(String newInput) {
		super(newInput);
	}
	
}
