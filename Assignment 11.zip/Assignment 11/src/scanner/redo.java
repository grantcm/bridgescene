package scanner;

import util.annotations.Tags;

@Tags({ "redo" })

public class redo extends word implements WordInterface{

	public redo(String newInput) {
		
		super(newInput);
	}
}
