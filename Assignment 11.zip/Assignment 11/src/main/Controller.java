package main;

import java.awt.event.KeyListener;
import java.awt.event.MouseListener;

public interface Controller extends MouseListener, KeyListener{

}
