package scanner;
import util.annotations.Tags;

@Tags({"rotateLeftArm"})

public class rotateLeftArm extends word implements WordInterface{

	public rotateLeftArm(String newInput){
		super(newInput);
	}
}
