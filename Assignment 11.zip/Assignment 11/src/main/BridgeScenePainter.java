package main;

import java.awt.BasicStroke;
import java.awt.Color;
import java.awt.Component;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Image;
import java.awt.Toolkit;
import java.beans.PropertyChangeEvent;

import avatar.BridgeScene;
import avatar.Circle;
import avatar.ImageShape;
import avatar.Line;
import avatar.StringShape;
import util.models.PropertyListenerRegisterer;

public class BridgeScenePainter extends Component implements java.beans.PropertyChangeListener{
	int headoffset=10;
	BridgeScene Scene;
    BasicStroke dotted = new BasicStroke(5f, BasicStroke.CAP_ROUND, BasicStroke.JOIN_ROUND, 
            5f, new float[] {2f}, 0f);
	PropertyListenerSupport propertysupport = new APropertyListenerSupport();
	 public BridgeScenePainter(BridgeScene theScene){
		 	setFocusable(true);
	    	Scene = theScene;
	    	//Arthur
	    	Scene.getArthur().getLegs().addPropertyChangeListener(this);
			Scene.getArthur().getArms().addPropertyChangeListener(this);
			Scene.getArthur().getBody().addPropertyChangeListener(this);
			Scene.getArthur().getHead().addPropertyChangeListener(this);
			Scene.getArthur().getText().addPropertyChangeListener(this);
			Scene.getArthur().getArms().getLeftLine().addPropertyChangeListener(this);
			Scene.getArthur().getArms().getRightLine().addPropertyChangeListener(this);
			Scene.getArthur().getLegs().getLeftLine().addPropertyChangeListener(this);
			//Galahad
			Scene.getGalahad().getLegs().addPropertyChangeListener(this);
			Scene.getGalahad().getArms().addPropertyChangeListener(this);
			Scene.getGalahad().getBody().addPropertyChangeListener(this);
			Scene.getGalahad().getHead().addPropertyChangeListener(this);
			Scene.getGalahad().getText().addPropertyChangeListener(this);
			Scene.getGalahad().getArms().getLeftLine().addPropertyChangeListener(this);
			Scene.getGalahad().getArms().getRightLine().addPropertyChangeListener(this);
			Scene.getGalahad().getLegs().getLeftLine().addPropertyChangeListener(this);
			//Lancelot
			Scene.getLancelot().getLegs().addPropertyChangeListener(this);
			Scene.getLancelot().getArms().addPropertyChangeListener(this);
			Scene.getLancelot().getBody().addPropertyChangeListener(this);
			Scene.getLancelot().getHead().addPropertyChangeListener(this);
			Scene.getLancelot().getText().addPropertyChangeListener(this);
			Scene.getLancelot().getArms().getLeftLine().addPropertyChangeListener(this);
			Scene.getLancelot().getArms().getRightLine().addPropertyChangeListener(this);
			Scene.getLancelot().getLegs().getLeftLine().addPropertyChangeListener(this);
			//Robin
			Scene.getRobin().getLegs().addPropertyChangeListener(this);
			Scene.getRobin().getArms().addPropertyChangeListener(this);
			Scene.getRobin().getBody().addPropertyChangeListener(this);
			Scene.getRobin().getHead().addPropertyChangeListener(this);
			Scene.getRobin().getText().addPropertyChangeListener(this);
			Scene.getRobin().getArms().getLeftLine().addPropertyChangeListener(this);
			Scene.getRobin().getArms().getRightLine().addPropertyChangeListener(this);
			Scene.getRobin().getLegs().getLeftLine().addPropertyChangeListener(this);
			//Guard
			Scene.getGuard().getLegs().addPropertyChangeListener(this);
			Scene.getGuard().getArms().addPropertyChangeListener(this);
			Scene.getGuard().getBody().addPropertyChangeListener(this);
			Scene.getGuard().getHead().addPropertyChangeListener(this);
			Scene.getGuard().getText().addPropertyChangeListener(this);
			Scene.getGuard().getArms().getLeftLine().addPropertyChangeListener(this);
			Scene.getGuard().getArms().getRightLine().addPropertyChangeListener(this);
			Scene.getGuard().getLegs().getLeftLine().addPropertyChangeListener(this);
			
	    }
	public void paint(Graphics g) {
        super.paint(g);
        Graphics2D g2 = (Graphics2D) g;
        g2.setStroke(dotted);
        g.setColor(Color.BLACK);     
        draw(g2, Scene);
    }
    
    public void draw(Graphics2D g, BridgeScene scene) {
    	//Arthur
    	draw(g, scene.getArthur().getHead());
        draw(g, scene.getArthur().getText());
        draw(g, scene.getArthur().getArms().getLeftLine());
        draw(g, scene.getArthur().getArms().getRightLine());
        draw(g, scene.getArthur().getLegs().getLeftLine());
        draw(g, scene.getArthur().getLegs().getRightLine());
        draw(g, scene.getArthur().getBody());
        //Lancelot
        draw(g, scene.getLancelot().getHead());
        draw(g, scene.getLancelot().getText());
        draw(g, scene.getLancelot().getArms().getLeftLine());
        draw(g, scene.getLancelot().getArms().getRightLine());
        draw(g, scene.getLancelot().getLegs().getLeftLine());
        draw(g, scene.getLancelot().getLegs().getRightLine());
        draw(g, scene.getLancelot().getBody());
        //Robin
        draw(g, scene.getRobin().getHead());
        draw(g, scene.getRobin().getText());
        draw(g, scene.getRobin().getArms().getLeftLine());
        draw(g, scene.getRobin().getArms().getRightLine());
        draw(g, scene.getRobin().getLegs().getLeftLine());
        draw(g, scene.getRobin().getLegs().getRightLine());
        draw(g, scene.getRobin().getBody());
        //Galahad
        draw(g, scene.getGalahad().getHead());
        draw(g, scene.getGalahad().getText());
        draw(g, scene.getGalahad().getArms().getLeftLine());
        draw(g, scene.getGalahad().getArms().getRightLine());
        draw(g, scene.getGalahad().getLegs().getLeftLine());
        draw(g, scene.getGalahad().getLegs().getRightLine());
        draw(g, scene.getGalahad().getBody());
        
        //Guard
        draw(g, scene.getGuard().getHead());
        draw(g, scene.getGuard().getText());
        draw(g, scene.getGuard().getArms().getLeftLine());
        draw(g, scene.getGuard().getArms().getRightLine());
        draw(g, scene.getGuard().getLegs().getLeftLine());
        draw(g, scene.getGuard().getLegs().getRightLine());
        draw(g, scene.getGuard().getBody());
        
        //KnightArea GuardArea
        
        draw(g, scene.getKnightArea());
        draw(g, scene.getGuardArea());
        
        //Gorge
        
        draw(g, scene.getGorge().getBridge1());
        draw(g, scene.getGorge().getBridge2());
        draw(g, scene.getGorge().getLeftSide());
        draw(g, scene.getGorge().getRightSide());
        
    }

    public void draw(Graphics g, StringShape aLabel) {
        String s = aLabel.getText();
        g.drawString(s, aLabel.getX(), aLabel.getY());      
    }
    
    public  void draw(Graphics2D g, ImageShape anImage) {
        Image img = Toolkit.getDefaultToolkit().getImage(anImage.getImageFileName());
        g.drawImage(img, anImage.getX(), anImage.getY()-headoffset, this);     
    }
    public  void draw(Graphics2D g, Line aLine) {
    	
        g.drawLine(aLine.getX(), aLine.getY(), aLine.getX2(), aLine.getY2());    
    }
    public void draw(Graphics2D g, Circle aCircle){
    	g.drawOval(aCircle.getX(), aCircle.getY(), aCircle.getWidth(), aCircle.getHeight());
    }

	public void propertyChange(PropertyChangeEvent arg0) {
		
		repaint();
	}
	public void register (PropertyListenerRegisterer aPropertyChangeRegister){
		aPropertyChangeRegister.addPropertyChangeListener(this);        
	}
}
