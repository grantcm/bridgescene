package scanner;

import java.util.List;
import java.util.ArrayList;

import util.annotations.Tags;

@Tags({ "CommandList" })
public class CommandList implements CommandListInterface {

	List<Runnable> commands = new ArrayList<Runnable>();

	public CommandList() {

	}

	@Tags({ "add" })
	public void addCommand( Runnable newCommand) {
		commands.add( newCommand);
	}

	public synchronized void run() {
		for(Runnable r:commands){
			r.run();
		}
		
	}

}
