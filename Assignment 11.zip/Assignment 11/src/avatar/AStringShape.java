package avatar;

import java.beans.PropertyChangeEvent;

import util.annotations.StructurePattern;
import util.annotations.StructurePatternNames;

@StructurePattern(StructurePatternNames.STRING_PATTERN)
public class AStringShape extends ALocatable implements StringShape, util.models.PropertyListenerRegisterer {
	String text;
	int x, y;

	public AStringShape(String initText, int initX, int initY) {
		super(initX, initY);
		text = initText;

	}

	public String getText() {
		return text;
	}

	public void setText(String newVal) {
		String oldVal =text;
		text = newVal;
		propertysupport.notifyAllListeners(new PropertyChangeEvent(this, "Text", oldVal, newVal));

	}

}
