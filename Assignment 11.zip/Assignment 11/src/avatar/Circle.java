package avatar;

public interface Circle extends BoundedShape{
	
	public void moveCircle(int X , int Y);
}
