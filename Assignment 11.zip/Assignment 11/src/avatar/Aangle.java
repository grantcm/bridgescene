package avatar;

import java.beans.PropertyChangeListener;

import main.APropertyListenerSupport;
import main.PropertyListenerSupport;
import util.annotations.StructurePattern;
import util.annotations.Tags;
import util.models.PropertyListenerRegisterer;

@StructurePattern("Bean Pattern")
@Tags("Angle")

public class Aangle implements Angle, PropertyListenerRegisterer{

	PropertyListenerSupport propertysupport = new APropertyListenerSupport();
	
	int width, height, OriginX, OriginY;
	
	Line LeftLine;
	Line RightLine;

	public Aangle() {

		
		LeftLine = new ALine(OriginX,OriginY, -width, height);
		RightLine = new ALine(OriginX,OriginY, width, height);

	}

	public Aangle(int initX, int initY, int x, int y) {

		OriginX = initX;
		OriginY = initY;
		width=x;
		height=y;
		LeftLine = new ALine(OriginX,OriginY, -width, height);
		RightLine = new ALine(OriginX,OriginY, width, height);

	}

	
	public void setOrigin(int x, int y){
		
		LeftLine.setX(x);
		LeftLine.setY(y);
		RightLine.setX(x);
		RightLine.setY(y);
		
	}
	public void setLength(int x, int y){
		LeftLine.setHeight(y);
		LeftLine.setWidth(x);
		RightLine.setHeight(y);
		RightLine.setWidth(-x);
	}

	public Line getLeftLine() {
		return LeftLine;
	}

	public Line getRightLine() {
		return RightLine;
	}

	@Override
	public void addPropertyChangeListener(PropertyChangeListener arg0) {
		propertysupport.add(arg0);
	}
}
