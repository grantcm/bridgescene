package avatar;

import java.beans.PropertyChangeListener;

public interface Line extends Locatable {
   
    public int getWidth();
    public void setWidth(int newVal);
    public int getHeight() ;
    public void setHeight(int newVal);
	public void rotateLine(double angle);
	public void addPropertyChangeListener(PropertyChangeListener arg0);
	public int getY2();
	public int getX2();
}
