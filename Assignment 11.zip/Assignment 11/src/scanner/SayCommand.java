package scanner;



import avatar.BridgeScene;
import util.annotations.Tags;
@Tags({"SayCommand"})
public class SayCommand implements Runnable{
	BridgeScene Scene;
    String newText;
    
    
    public SayCommand (BridgeScene newScene, String newString){
    	Scene=newScene;
    	newText=newString;
    }

	public  void run() {
		Scene.SayScene(newText);
		
	}

}
