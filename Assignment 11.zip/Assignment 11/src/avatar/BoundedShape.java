package avatar;

import util.annotations.Tags;

@Tags({"Locatable" ,"BoundedShape"})
public interface BoundedShape extends Locatable {
	public int getWidth();
	public int getHeight();
	public void setHeight(int newHeight);
	public void setWidth(int newWidth);
	
}
