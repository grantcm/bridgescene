package scanner;

import avatar.BridgeScene;
import util.misc.ThreadSupport;

public class FailCommand implements Runnable {
	private int animationPauseTime = 30;
	BridgeScene Scene;

	public FailCommand(BridgeScene newScene) {
		Scene = newScene;

	}

	public void run() {
		synchronized (this) {
			Scene.FailedScene();
			ThreadSupport.sleep(animationPauseTime);
		}
	}

}