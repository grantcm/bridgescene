package avatar;

public interface ImageShape extends BoundedShape {
	
    public String getImageFileName() ;  
    public void setImageFileName(String newVal);
}
