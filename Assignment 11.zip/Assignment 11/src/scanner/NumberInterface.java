package scanner;
public interface NumberInterface  extends TokenInterface{
	
	int getNumValue();
	
}