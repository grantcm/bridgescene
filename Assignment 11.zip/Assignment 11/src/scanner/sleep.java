package scanner;
import util.annotations.Tags;

@Tags({ "sleep" })

public class sleep extends word implements WordInterface{

	public sleep(String newInput) {

		super(newInput);
	}
}
