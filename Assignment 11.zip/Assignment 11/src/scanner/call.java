package scanner;

import util.annotations.Tags;

@Tags({ "call" })

public class call extends word implements WordInterface{

	public call(String newInput) {
		
		super(newInput);
	}
}
