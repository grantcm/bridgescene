package avatar;

import util.annotations.StructurePattern;

@StructurePattern("Bean Pattern")
public class AGorge implements Gorge {
	Line LeftSide;
	Line RightSide;
	Line Bridge1;
	Line Bridge2;
	int OrigX, OrigY;
	
	public AGorge (){
		OrigX=500;
		OrigY=50;
		LeftSide = new ALine(OrigX,OrigY,0,800);
		RightSide = new ALine(OrigX+200,OrigY,0,800);
		Bridge1 = new ALine(OrigX,OrigY+350,200,0);
		Bridge2 = new ALine(OrigX,OrigY+400,200,0);
	}
	
	public Line getLeftSide (){
		return LeftSide;
	}
	public Line getRightSide (){
		return RightSide;
	}
	public Line getBridge1 (){
		return Bridge1;
	}
	public Line getBridge2 (){
		return Bridge2;
	}
	public void moveGorge(int x, int y){
		OrigX+=x;
		OrigY+=y;
		
		LeftSide.setX(OrigX);
		LeftSide.setY(OrigY);
		RightSide.setX(OrigX+200);
		RightSide.setY(OrigY);
		Bridge1.setX(OrigX);
		Bridge1.setY(OrigY+350);
		Bridge2.setX(OrigX);
		Bridge2.setY(OrigY+400);
	}
}
