package scanner;

public interface BeanInterface {
	
	 void setScannedString(String input);
	String getScannedString();
	TokenInterface[] getTokens();
	 
}
