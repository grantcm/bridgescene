package scanner;
import util.annotations.Tags;
import util.annotations.StructurePattern;
import util.annotations.StructurePatternNames;
import util.annotations.PropertyNames;
import util.annotations.EditablePropertyNames;

@Tags({ "Number" })
@StructurePattern(StructurePatternNames.BEAN_PATTERN)
@PropertyNames({ "Input", "Value" })
@EditablePropertyNames({ "Input" })

public class number extends word implements NumberInterface {

	String Input;
	String Value="";
	int NumValue;

	number(String newInput) {
		super(newInput);
		Input=newInput;
	}

	public int getNumValue() {
		NumValue=Integer.parseInt(Input);
		return NumValue;
	}

	
}
