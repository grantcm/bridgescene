package main;

import java.awt.Component;
import java.awt.event.KeyListener;
import java.awt.event.MouseListener;
import java.beans.PropertyChangeListener;

import javax.swing.JFrame;
import javax.swing.JTextField;

import avatar.ABridgeScene;
import avatar.BridgeScene;
import bus.uigen.OEFrame;
import bus.uigen.ObjectEditor;
import scanner.BeanInterface;
import scanner.ACommandInterpreter;
import scanner.CommandInterpreter;
import scanner.MoveCommand;
import util.misc.ThreadSupport;

public class Assignment12 {

	static int sleeptime = 1000;
	
	public static void main(String[] args) {
		BridgeScene NewBridge = new ABridgeScene();
		BridgeScenePainter view = new BridgeScenePainter(NewBridge);
		ClearanceManager Manager = new AClearanceManager();
		
		
		
//		JFrame frame = new JFrame("a Scene View");
//		frame.add((Component) view);
//		frame.setSize(1000, 1000);
//		frame.setVisible(true);

		Controller controller = new AController(NewBridge, view);

		
		BeanInterface NewBean = new scanner.Bean();
		CommandInterpreter Command = new ACommandInterpreter(NewBridge, NewBean, Manager);
		PropertyChangeListener theMonitor = new ConsoleSceneView(NewBridge, Command);

		OEFrame Commandinterpret = ObjectEditor.edit(Command);
		OEFrame Scene = ObjectEditor.edit(NewBridge);
		Scene.setSize(1000, 700);
		OEFrame Clearance = ObjectEditor.edit(Manager);
		
		
		
		Command.waitingArthur();
		Command.waitingGalahad();
		Command.waitingLancelot();
		Command.waitingRobin();
		
		ThreadSupport.sleep(sleeptime);
		
		
		ThreadSupport.sleep(4000);
		
		
//		Command.setCommand("{ move arthur +100 +100 move lancelot +100 -100 }");
//
//		
//		ThreadSupport.sleep(sleeptime);
//		Command.setCommand("approach Lancelot");
//		ThreadSupport.sleep(sleeptime);
//		Command.setCommand("Say  \"Quest?\" ");
//		ThreadSupport.sleep(sleeptime);
//		Command.setCommand("Say  \"The holy grail\" ");	
//		ThreadSupport.sleep(sleeptime);
//		Command.setCommand("Pass");
//		ThreadSupport.sleep(sleeptime);
//		Command.setCommand("approach Arthur");
//		ThreadSupport.sleep(sleeptime);
//		Command.setCommand("Say  \"What is your quest?\" ");
//		ThreadSupport.sleep(sleeptime);
//		Command.setCommand("Say  \"The holy grail\" ");
//		ThreadSupport.sleep(sleeptime);
//		Command.setCommand("Say  \"you shall not pass\" ");
//		ThreadSupport.sleep(sleeptime);
//		Command.setCommand("Say  \"stop me\" ");
//		ThreadSupport.sleep(sleeptime);
//		Command.setCommand("Fail");
//		ThreadSupport.sleep(sleeptime);
//		Command.setCommand("Pass");
//		ThreadSupport.sleep(sleeptime);
//		Command.setCommand("repeat 3 move robin +100 -100");
		
	}
}
