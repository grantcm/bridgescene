package scanner;

import util.annotations.Tags;

@Tags("approach")
public class Approach extends word implements WordInterface {
	public Approach(String newInput){
		super(newInput);
	}
}
