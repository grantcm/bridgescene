package avatar;

import java.beans.PropertyChangeEvent;
import java.beans.PropertyChangeListener;

import main.APropertyListenerSupport;
import main.PropertyListenerSupport;
import util.annotations.PropertyNames;
import util.annotations.Tags;
import util.models.PropertyListenerRegisterer;

@Tags({ "Locatable" })
@PropertyNames({ "X", "Y" })

public abstract class ALocatable implements Locatable, PropertyListenerRegisterer {
	int X, Y;

	PropertyListenerSupport propertysupport = new APropertyListenerSupport();

	public ALocatable(int newx, int newy) {
		X = newx;
		Y = newy;
	}

	public void setX(int newX) {
		int oldX=X;
		X = newX;
		propertysupport.notifyAllListeners(new PropertyChangeEvent(this, "X", oldX, newX));
	}

	public void setY(int newY) {
		int oldY=Y;
		Y = newY;
		propertysupport.notifyAllListeners(new PropertyChangeEvent(this, "Y",
				oldY, newY));
	}

	public int getX() {
		return X;
	}

	public int getY() {
		return Y;
	}
	
	public void addPropertyChangeListener(PropertyChangeListener arg0) {
		propertysupport.add(arg0);
	}
}
