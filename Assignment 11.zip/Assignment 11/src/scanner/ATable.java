 package scanner;

import java.util.ArrayList;

import util.annotations.StructurePattern;
import util.annotations.Tags;
@StructurePattern("Map Pattern")
@Tags({"Table","generic"})
public class ATable<K,V> implements Table<K,V>{
	ArrayList<String> Keys = new ArrayList<String>();
	
	ArrayList<Object> Values = new ArrayList<Object>();
	
	int i,length;
	
	public void put (String key, Object val){
		if(Keys.contains(key)){
			Values.set(Keys.indexOf(key), val);
		}else {
		Keys.add(key);
		Values.add(val);
		System.out.println("Put: "+ Values);
		}
	}
	public Object get (String key){
		i= Keys.indexOf(key);
		System.out.println("Get: "+ Values.get(i));
		return Values.get(i);
		
	}
	public Object get (int index){
		return Values.get(index);
	}
	public int length(){
		length=Keys.size();
		return length;
	}
}
