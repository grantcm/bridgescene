package scanner;

import util.annotations.Tags;

@Tags({ "thread" })

public class thread extends word implements WordInterface{

	public thread(String newInput) {
		
		super(newInput);
	}
}
