package avatar;

import java.beans.PropertyChangeEvent;

import util.annotations.StructurePattern;
import util.annotations.StructurePatternNames;

@StructurePattern(StructurePatternNames.LABEL_PATTERN)
public class AShapeImage extends ABoundedShape implements ImageShape, util.models.PropertyListenerRegisterer {
	String imageFileName;
	int x, y, height, width;

	public AShapeImage(String initImageFileName, int initX, int initY, int initHeight, int initWidth) {
		super(initX, initY, initHeight, initWidth);
		imageFileName = initImageFileName;

	}

	public String getImageFileName() {
		return imageFileName;
	}

	public void setImageFileName(String newVal) {
		String oldVal = imageFileName;
		imageFileName = newVal;
		propertysupport.notifyAllListeners(new PropertyChangeEvent(this, "ImageFileName",
				oldVal, newVal));
	}

}
