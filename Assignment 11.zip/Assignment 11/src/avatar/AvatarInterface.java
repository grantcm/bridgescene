package avatar;

import java.beans.PropertyChangeListener;

public interface AvatarInterface {
	public Angle getArms();
	public Angle getLegs();
	public Line getBody();
	public ImageShape getHead();
	public StringShape getText();
	public void moveAvatar(int x, int y);
	public void moveOrigin();
	public void setText(String newText);
	public void setScale(int scale);
	public void setX(int newX);
	public void setY(int newY);
	public int getX();
	public int getY();
	public void addPropertyChangeListener(PropertyChangeListener arg0);

	
}
