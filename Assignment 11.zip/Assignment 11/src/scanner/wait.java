package scanner;

import util.annotations.Tags;

@Tags({ "wait" })

public class wait extends word implements WordInterface{

	public wait(String newInput) {
		
		super(newInput);
	}
}
