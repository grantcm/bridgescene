package avatar;

public interface Gorge {
	public Line getLeftSide ();
	public Line getRightSide ();
	public Line getBridge1 ();
	public Line getBridge2 ();
	public void moveGorge(int x, int y);
}
