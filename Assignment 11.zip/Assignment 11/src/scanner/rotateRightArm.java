package scanner;
import util.annotations.Tags;

@Tags({"rotateRightArm"})

public class rotateRightArm extends word implements WordInterface{
	
	public rotateRightArm(String newInput){
		super(newInput);
	}
}
