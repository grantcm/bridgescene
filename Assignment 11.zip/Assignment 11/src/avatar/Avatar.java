package avatar;

import util.annotations.StructurePattern;
import util.annotations.Tags;
import util.annotations.Visible;

import java.beans.PropertyChangeEvent;
import java.beans.PropertyChangeListener;

import main.APropertyListenerSupport;
import main.PropertyListenerSupport;
import util.annotations.PropertyNames;
@PropertyNames({"Head","Arms","Legs","Body","Text","Scale","X","Y"})
@Tags({"Avatar"})
@StructurePattern("Bean Pattern")

public class Avatar implements AvatarInterface, util.models.PropertyListenerRegisterer {
	Angle Arms;
	Angle Legs;
	Line Body;
	ImageShape Head;
	int X, Y, OrigX, OrigY,Scale,ArmWidth=10,ArmHeight=20,LegHeight=30,TextXOffset=25,TextYOffset=40,HeadParam=50,BodyX=0;
	Point Origin;
	String HeadName;
	String TextIn;
	StringShape Text;
	PropertyListenerSupport propertysupport = new APropertyListenerSupport();

	

	public Avatar(int OriginX, int OriginY, String temp, String newText, int scale) {
	
		OrigX = OriginX;
		OrigY = OriginY;
		HeadName=temp;
		TextIn=newText;
		Scale=scale;
		Origin=new APoint(OrigX, OrigY);
		Arms = new Aangle(OrigX, OrigY,ArmWidth*Scale, ArmHeight*Scale);
		Legs = new Aangle(OrigX, OrigY + LegHeight*Scale, ArmWidth*Scale, LegHeight*Scale);
		Body = new ALine(OrigX,OrigY, BodyX, LegHeight*Scale);
		Head = new AShapeImage(HeadName, OrigX-ArmHeight, OrigY-HeadParam, HeadParam, HeadParam);
		Text= new AStringShape(TextIn,OrigX+TextXOffset,OrigY-TextYOffset);
		
	}
	@Tags("move")
	public void moveAvatar(int x, int y){
	
		OrigX+=x;
		OrigY+=y;
		Origin.setX(OrigX);
		Origin.setY(OrigY);
		Arms.setOrigin(OrigX,OrigY);
		Legs.setOrigin(OrigX,OrigY+LegHeight*Scale);
		Body.setX(OrigX);
		Body.setY(OrigY);
		Head.setX(OrigX-ArmHeight);
		Head.setY(OrigY-HeadParam);
		Text.setX(OrigX+TextXOffset);
		Text.setY(OrigY-TextYOffset);
	
	}
	public synchronized void moveOrigin(){
		
		Origin.setX(OrigX);
		Origin.setY(OrigY);
		Arms.setOrigin(OrigX,OrigY);
		Legs.setOrigin(OrigX,OrigY+LegHeight*Scale);
		Body.setX(OrigX);
		Body.setY(OrigY);
		Head.setX(OrigX-ArmHeight);
		Head.setY(OrigY-HeadParam);
		Text.setX(OrigX+TextXOffset);
		Text.setY(OrigY-TextYOffset);
	}
	
	
	
	public void setText(String newText){
		Text.setText(newText);
	}
	@Tags("scale")
	public void setScale(int scale){
		Scale=scale;
		Legs.setOrigin(OrigX, OrigY+LegHeight*Scale);
		Legs.setLength(ArmWidth*Scale,LegHeight*Scale);
		Arms.setOrigin(OrigX, OrigY);
		Arms.setLength(ArmWidth*Scale,ArmHeight*Scale);
		Body.setHeight(LegHeight*Scale);
	}
	
	public StringShape getText(){
		return Text;
	}

	public Angle getArms() {
		return Arms;
	}

	public Angle getLegs() {
		return Legs;
	}

	public Line getBody() {
		return Body;
	}

	public ImageShape getHead() {
		return Head;
	}
	@Visible(false)
	public int getX(){
		return OrigX;
	}
	@Visible(false)
	public int getY(){
		return OrigY;
	}

	public void setX(int newX){
		int oldX=OrigX;
		OrigX=newX;
		propertysupport.notifyAllListeners(new PropertyChangeEvent(this, "X", oldX, newX));
	}

	public void setY(int newY){
		int oldY=OrigY;
		OrigY=newY;
		propertysupport.notifyAllListeners(new PropertyChangeEvent(this, "X", oldY, newY));
	}
	@Override
	public void addPropertyChangeListener(PropertyChangeListener arg0) {
		propertysupport.add(arg0);
	}
}
