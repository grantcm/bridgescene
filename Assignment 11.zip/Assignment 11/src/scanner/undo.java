package scanner;
import util.annotations.Tags;

@Tags({ "undo" })

public class undo extends word implements WordInterface{

	public undo(String newInput) {
		
		super(newInput);
	}
}
